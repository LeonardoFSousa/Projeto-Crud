import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createLivro, getLivroById, updateLivro} from '../services/api';
interface Livro {
    titulo: string;
    autor: string;
    ano_de_publicacao: number;
    genero: string;
    numero_de_paginas: number;
}
function LivroForm() {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const [livro, setLivro] = useState<Livro>({
        titulo: '',
        autor: '',
        ano_de_publicacao: 0,
        genero: '',
        numero_de_paginas: 0,
    });
    useEffect(() => {
        if (id) {
            loadLivro();
        }
    }, [id]);
    const loadLivro = async () => {
        try {
            const response = await getLivroById(id as string);
            setLivro(response.data);
        } catch (error) {
            console.error("Error loading product data", error);
        }
    };
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setLivro({
            ...livro,
            [e.target.name]: e.target.value,
        });
    };
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            if (id) {
                await updateLivro(id, livro);
            } else {
                await createLivro(livro);
            }
            navigate('/');
        } catch (error) {
            alert("Erro ao salvar o livro. Por favor, tente novamente.");
        }
    };
    return (
        <form onSubmit={handleSubmit}>
            <div>
                <label> Titulo </label>
                <input
                    type="text"
                    name="titulo"
                    value={livro.titulo}
                    onChange={handleChange}
                />
            </div>
            <div>
                <label> Autor </label>
                <input
                    type="text"
                    name="autor"
                    value={livro.autor}
                    onChange={handleChange}
                />
            </div>
            <div>
                <label> Ano de Publicação </label>
                <input
                    type="number"
                    name="ano_de_publicacao"
                    value={livro.ano_de_publicacao}
                    onChange={handleChange}
                />
            </div>
            <div>
                <label> Gênero </label>
                <input
                    type="text"
                    name="genero"
                    value={livro.genero}
                    onChange={handleChange}
                />
            </div>
            <div>
                <label> Número de Páginas </label>
                <input
                    type="number"
                    name="numero_de_paginas"
                    value={livro.numero_de_paginas}
                    onChange={handleChange}
                />
            </div>
            <button type="submit"> Salvar </button>
        </form>
    );
}
export default LivroForm;