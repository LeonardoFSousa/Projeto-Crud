import LivroList from '../components/LivrosList';
function Home() {
    return (
        <div>
            <h1>Livros Cadastrados</h1>
            <LivroList />
        </div>
    );
}
export default Home;
