import LivroForm from '../components/LivrosForm';
function EditLivro() {
    return (
        <div>
            <h1> Editar Livro </h1>
            <LivroForm />
        </div>
    );
}
export default EditLivro;