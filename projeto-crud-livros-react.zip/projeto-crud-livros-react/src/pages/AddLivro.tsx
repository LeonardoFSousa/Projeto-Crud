import LivroForm from '../components/LivrosForm';
function AddLivro() {
    return (
        <div>
            <h1> Adicionar um Livro </h1>
            <LivroForm />
        </div>
    );
}
export default AddLivro;